def print_banner():
    print(r"""
╔════════════════════════════╗
║      hello_friend v3.0     ║
║        ONLY LEGAL          ║
╚════════════════════════════╝
    """)

def save_report(filename, data):
    with open(filename, "w", encoding="utf-8") as f:
        f.write(f"Target: {data['target']}\n")
        f.write(f"Type: {data['type']}\n")
        f.write(f"Time: {data['timestamp']}\n")
        f.write("-" * 50 + "\n")
        for item in data["results"]:
            f.write(f"{item}\n")
    print(f"[+] Report saved: {filename}")

def green(text):
    return f"\033[92m{text}\033[0m"

def red(text):
    return f"\033[91m{text}\033[0m"

def yellow(text):
    return f"\033[93m{text}\033[0m"
