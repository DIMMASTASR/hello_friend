#!/usr/bin/env python3
import sys
import os
from datetime import datetime
from modules import nick, email, phone, photo, domain, vin, plate
from utils.helpers import save_report, print_banner

def main():
    print_banner()
    print("\033[96m")
    print("💬 «Hello, friend.»")
    print("   — Elliot Alderson")
    print("\033[0m\n")

    target = input("[?] Введи цель: ").strip()
    if not target:
        print("[!] Ничего не введено")
        return

    print("\n[+] Выбери тип цели:")
    print("  1 — Ник")
    print("  2 — Email")
    print("  3 — Телефон")
    print("  4 — Фото")
    print("  5 — Домен")
    print("  6 — VIN")
    print("  7 — Госномер")
    choice = input("[?] Твой выбор (1-7): ").strip()

    result_data = {
        "target": target,
        "type": choice,
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "results": []
    }

    if choice == "1":
        result_data["results"] = nick.scan(target)
    elif choice == "2":
        result_data["results"] = email.scan(target)
    elif choice == "3":
        result_data["results"] = phone.scan(target)
    elif choice == "4":
        result_data["results"] = photo.scan(target)
    elif choice == "5":
        result_data["results"] = domain.scan(target)
    elif choice == "6":
        result_data["results"] = vin.scan(target)
    elif choice == "7":
        result_data["results"] = plate.scan(target)
    else:
        print("[!] Неверный выбор")
        return

    os.makedirs("output", exist_ok=True)
    filename = f"output/{target}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
    save_report(filename, result_data)
    print(f"\n[+] Отчёт сохранён: {filename}")
    print("\n\033[92m💾 Оставайся в безопасности. Друг.\033[0m")

if __name__ == "__main__":
    main()
