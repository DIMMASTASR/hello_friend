# hello_friend 🔐

OSINT-инструмент в стиле **Mr. Robot**.  
Ищет информацию по открытым источникам: ник, email, телефон, фото, домен, VIN, госномер.

> *«Hello, friend.»* — Эллиот Алдерсон

---

## 🧠 Возможности

| Тип | Что ищет |
|-----|----------|
| **Ник** | 50+ соцсетей (VK, Instagram, Telegram, GitHub, и др.) |
| **Email** | Проверка утечек через haveibeenpwned |
| **Телефон** | Telegram, VK, Avito, Google |
| **Фото** | EXIF-данные + поиск по картинкам (Yandex/Google) |
| **Домен** | WHOIS, DNS, IP, поддомены |
| **VIN** | Расшифровка через открытые декодеры |
| **Госномер** | ГИБДД, Автотека, Avito, Drom.ru |

---

## ⚖️ Легальность

**Только открытые источники.**  
Никаких слитых баз, никакого доксинга.  
Всё, что умеет инструмент, можно найти вручную через браузер.

---

## 📦 Установка

```bash
git clone https://github.com/твой_ник/hello_friend.git
cd hello_friend
pip install -r requirements.txt
python3 scanner.py
