import requests
from utils.helpers import green, red, yellow

SITES = {
    "VK": "https://vk.com/{}",
    "Instagram": "https://instagram.com/{}",
    "Twitter": "https://twitter.com/{}",
    "GitHub": "https://github.com/{}",
    "Telegram": "https://t.me/{}",
    "YouTube": "https://youtube.com/@{}",
    "TikTok": "https://tiktok.com/@{}",
    "Facebook": "https://facebook.com/{}",
    "Twitch": "https://twitch.tv/{}",
    "Steam": "https://steamcommunity.com/id/{}",
    "Reddit": "https://reddit.com/user/{}",
    "Pinterest": "https://pinterest.com/{}",
    "Spotify": "https://open.spotify.com/user/{}",
    "Snapchat": "https://snapchat.com/add/{}",
    "Discord": "https://discord.com/users/{}",
    "GitLab": "https://gitlab.com/{}",
    "Medium": "https://medium.com/@{}",
    "DeviantArt": "https://deviantart.com/{}",
    "Behance": "https://behance.net/{}",
    "Dribbble": "https://dribbble.com/{}",
    "Flickr": "https://flickr.com/people/{}",
    "Patreon": "https://patreon.com/{}",
    "SoundCloud": "https://soundcloud.com/{}",
    "Bandcamp": "https://bandcamp.com/{}",
    "Myspace": "https://myspace.com/{}",
    "About.me": "https://about.me/{}",
    "Keybase": "https://keybase.io/{}",
    "Gravatar": "https://en.gravatar.com/{}",
    "WordPress": "https://{}.wordpress.com",
    "Blogger": "https://{}.blogspot.com",
    "Tumblr": "https://{}.tumblr.com",
    "LiveJournal": "https://{}.livejournal.com",
    "Pastebin": "https://pastebin.com/u/{}",
    "HackerNews": "https://news.ycombinator.com/user?id={}",
    "ProductHunt": "https://producthunt.com/@{}",
    "AngelList": "https://angel.co/u/{}",
    "Crunchbase": "https://crunchbase.com/person/{}",
    "LinkedIn": "https://linkedin.com/in/{}",
    "Xing": "https://xing.com/profile/{}",
    "ResearchGate": "https://researchgate.net/profile/{}",
    "Academia.edu": "https://independent.academia.edu/{}",
    "Goodreads": "https://goodreads.com/{}",
    "IMDb": "https://imdb.com/name/{}",
    "Letterboxd": "https://letterboxd.com/{}",
    "Trakt": "https://trakt.tv/users/{}",
    "Last.fm": "https://last.fm/user/{}",
    "Mixcloud": "https://mixcloud.com/{}",
    "ReverbNation": "https://reverbnation.com/{}",
    "Vimeo": "https://vimeo.com/{}",
    "Dailymotion": "https://dailymotion.com/{}",
    "OK.ru": "https://ok.ru/{}",
    "Мой Мир": "https://my.mail.ru/{}",
}

def scan(nick):
    print(f"\n[*] Searching for nickname: {nick}")
    results = []
    headers = {"User-Agent": "Mozilla/5.0"}
    for site, url_template in SITES.items():
        url = url_template.format(nick)
        try:
            r = requests.get(url, headers=headers, timeout=5, allow_redirects=True)
            if r.status_code == 200:
                msg = f"[+] {site}: {url}"
                print(green(msg))
                results.append(msg)
            elif r.status_code == 404:
                print(red(f"[-] {site}: not found"))
            else:
                print(yellow(f"[?] {site}: {r.status_code}"))
        except Exception as e:
            print(red(f"[!] Error checking {site}: {str(e)[:50]}"))
    return results
