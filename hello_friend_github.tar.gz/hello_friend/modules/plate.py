from utils.helpers import green, red, yellow

def scan(plate):
    print(f"\n[*] Searching for license plate: {plate}")
    results = []

    # ГИБДД (проверка истории)
    gibdd_url = f"https://xn--90adear.xn--p1ai/check/auto?plate={plate}"
    msg = f"[+] ГИБДД: {gibdd_url}"
    print(green(msg))
    results.append(msg)

    # Автотека
    autoteka_url = f"https://autoteka.ru/search?plate={plate}"
    msg = f"[+] Автотека: {autoteka_url}"
    print(green(msg))
    results.append(msg)

    # Avito
    avito_url = f"https://www.avito.ru/items?q={plate}"
    msg = f"[+] Avito: {avito_url}"
    print(green(msg))
    results.append(msg)

    # Drom.ru
    drom_url = f"https://drom.ru/search/?text={plate}"
    msg = f"[+] Drom.ru: {drom_url}"
    print(green(msg))
    results.append(msg)

    return results
